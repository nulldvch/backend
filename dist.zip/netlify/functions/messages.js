exports.handler = async function(event) {
  const headers = {
    "Content-Type": "application/json",
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "GET, POST, OPTIONS"
  };

  if (event.httpMethod === "OPTIONS") {
    return { statusCode: 200, headers, body: "" };
  }

  const raw = process.env.NETLIFY_BLOBS_CONTEXT;
  if (!raw) {
    return { statusCode: 503, headers, body: JSON.stringify({ error: "storage_unavailable" }) };
  }

  let blobsURL, siteID, token;
  try {
    const ctx = JSON.parse(Buffer.from(raw, "base64").toString("utf-8"));
    blobsURL = ctx.edgeURL || ctx.url;
    siteID   = ctx.siteID;
    token    = ctx.token;
    if (!blobsURL || !siteID || !token) throw new Error("incomplete");
  } catch (e) {
    return { statusCode: 503, headers, body: JSON.stringify({ error: "storage_unavailable" }) };
  }

  const endpoint = `${blobsURL}/${siteID}/messages/all`;
  const auth = { Authorization: `Bearer ${token}` };

  async function readMessages() {
    const res = await fetch(endpoint, { headers: auth });
    if (res.status === 404) return [];
    if (!res.ok) throw new Error(`Read failed: ${res.status}`);
    return res.json();
  }

  async function writeMessages(messages) {
    const res = await fetch(endpoint, {
      method: "PUT",
      headers: { ...auth, "Content-Type": "application/json" },
      body: JSON.stringify(messages)
    });
    if (!res.ok) throw new Error(`Write failed: ${res.status}`);
  }

  async function sendEmail(name, message) {
    const apiKey = process.env.RESEND_API_KEY;
    if (!apiKey) return;
    try {
      await fetch("https://api.resend.com/emails", {
        method: "POST",
        headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          from: "Message Board <onboarding@resend.dev>",
          to: "daichiibardaloza@zohomail.com",
          subject: `New message from ${name}`,
          html: `<div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:24px;">
            <h2 style="margin:0 0 16px;font-size:20px;">New message board submission</h2>
            <p style="margin:0 0 8px;color:#555;font-size:14px;">From: <strong>${name}</strong></p>
            <div style="background:#f4f4f8;border-radius:8px;padding:16px;font-size:15px;line-height:1.6;color:#222;">
              ${message.replace(/\n/g, "<br>")}
            </div>
            <p style="margin:16px 0 0;font-size:12px;color:#aaa;">Sent from your portfolio message board.</p>
          </div>`
        })
      });
    } catch (e) {}
  }

  if (event.httpMethod === "GET") {
    try {
      const messages = await readMessages();
      return { statusCode: 200, headers, body: JSON.stringify(messages) };
    } catch (e) {
      return { statusCode: 200, headers, body: "[]" };
    }
  }

  if (event.httpMethod === "POST") {
    try {
      const body = JSON.parse(event.body || "{}");
      if (!body.message || !body.message.trim()) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: "Message is required" }) };
      }
      if (body.message.trim().length > 300) {
        return { statusCode: 400, headers, body: JSON.stringify({ error: "Message too long (max 300 chars)" }) };
      }

      let messages = [];
      try { messages = await readMessages(); } catch (e) {}

      const newMsg = {
        id: Date.now().toString(),
        name: ((body.name || "").trim().slice(0, 50)) || "Anonymous",
        message: body.message.trim(),
        createdAt: new Date().toISOString()
      };

      messages.unshift(newMsg);
      const cutoff = Date.now() - 30 * 24 * 60 * 60 * 1000;
      messages = messages.filter(m => new Date(m.createdAt).getTime() > cutoff).slice(0, 100);

      await writeMessages(messages);
      await sendEmail(newMsg.name, newMsg.message);

      return { statusCode: 201, headers, body: JSON.stringify(newMsg) };
    } catch (e) {
      return { statusCode: 500, headers, body: JSON.stringify({ error: e.message }) };
    }
  }

  return { statusCode: 405, headers, body: "Method Not Allowed" };
};
